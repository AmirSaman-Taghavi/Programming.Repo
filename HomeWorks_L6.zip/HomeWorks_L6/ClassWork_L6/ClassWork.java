import java.sql.*;

public class ClassWork {
    public static void main(String[] args) {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@LAPTOP-UPV59LDR:1521:xe",
                    "mani", "samrod82");
            PreparedStatement preparedStatement = connection.prepareStatement("insert into person(Name, Pass, Username, Email)" +
                    "values (?, ?, ?, ?)");
            preparedStatement.setString(1, "mani");
            preparedStatement.setString(2, "samrod82");
            preparedStatement.setString(3, "maniii80");
            preparedStatement.setString(4, "xyz");
            System.out.println("insert into DB: " + preparedStatement.executeUpdate());

            preparedStatement.close();
            connection.close();
        } catch (ClassNotFoundException ce) {
            System.out.println("DB driver not exist!");
        } catch (SQLException se) {
            System.out.println("DB error:" + se.getMessage());
        }

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
                    "shayan", "amirsaman82");
            PreparedStatement preparedStatement = connection.prepareStatement("insert into person(Name, Pass, Username, Email)" +
                    "values (?, ?, ?, ?)");
            preparedStatement.setString(1, "shayan");
            preparedStatement.setString(2, "amirsaman82");
            preparedStatement.setString(3, "shayanqln12");
            preparedStatement.setString(4, "unb");

            preparedStatement.executeUpdate();
            preparedStatement.close();
            connection.close();
        } catch (ClassNotFoundException ce) {
            System.out.println("DB driver not exist!");
        } catch (SQLException se) {
            System.out.println("DB error:" + se.getMessage());
        }
    }
}
