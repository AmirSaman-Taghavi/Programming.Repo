import userinterface.UserInterface;
import userinterface.model.entity.UserEntity;
import userinterface.model.repository.UserRepo;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class Client {
    public static void main(String[] args) {
        try {
            System.out.println("Starting...");
            UserInterface userInterface = (UserInterface) Naming.lookup("//localhost/Customer");
            UserEntity userEntity = new UserEntity();
            userEntity.setId_Of_Food(4);
            userEntity.setPrice("90000");

            userInterface.takeAFood(new UserRepo());
        } catch (RemoteException rE) {
            rE.getStackTrace();
        } catch (NotBoundException nE) {
            nE.getStackTrace();
        } catch (MalformedURLException mE) {
            mE.getStackTrace();
        } catch (Exception e) {
            e.getStackTrace();
        }
    }
}
