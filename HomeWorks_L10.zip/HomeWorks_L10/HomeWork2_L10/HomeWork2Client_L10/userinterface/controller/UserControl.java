package userinterface.controller;

import userinterface.UserProcess;
import userinterface.model.entity.UserEntity;
import userinterface.model.repository.UserRepo;

public class UserControl {
    public void control() {
        try {
            UserRepo userRepo = new UserRepo();
            try {
                userRepo.connection();
            } catch (Exception e) {
                e.getStackTrace();
            }
        } catch (Exception e) {
            e.getStackTrace();
        }

        try {
            UserProcess userProcess = new UserProcess();
            try {
                userProcess.takeAFood(new UserRepo().foods_order(new UserEntity().setId_Of_Food(4).setPrice("90000").
                    setId_Of_Food(5).setPrice("40000")));
            } catch (Exception e) {
                e.getStackTrace();
            }
        } catch (Exception e) {
            e.getStackTrace();
        }
    }
}
