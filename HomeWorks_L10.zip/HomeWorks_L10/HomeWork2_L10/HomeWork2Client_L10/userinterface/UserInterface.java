package userinterface;

import userinterface.model.entity.UserEntity;
import userinterface.model.repository.UserRepo;

import java.rmi.Remote;
import java.util.List;

public interface UserInterface extends Remote {
    void takeAFood(UserRepo userRepo) throws Exception;
}
