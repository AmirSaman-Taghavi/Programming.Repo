package userinterface.model.entity;

public class UserEntity {
    private  int id_Of_Food;
    private String Price;

    public int getId_Of_Food() {
        return id_Of_Food;
    }

    public UserEntity setId_Of_Food(int id_Of_Food) {
        this.id_Of_Food = id_Of_Food;
        return this;
    }

    public String getPrice() {
        return Price;
    }

    public UserEntity setPrice(String price) {
        Price = price;
        return this;
    }
}

