package userinterface.model.repository;

import userinterface.model.entity.UserEntity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class UserRepo implements AutoCloseable{
    private Connection connection;
    private PreparedStatement preparedStatement;
    public void connection() throws Exception{
        Class.forName("oracle.jdbc.driver.OracleDriver");
        connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "server2"
            , "samrod82");
        connection.setAutoCommit(false);
    }

    public UserRepo foods_Table () throws Exception{
        preparedStatement = connection.prepareStatement("insert into foods(food_number, food_name, price) values" +
            "(?, ?, ?)");
        preparedStatement.setLong(1, 1);
        preparedStatement.setString(2, "Ghormesabzi");
        preparedStatement.setString(3, "120000T");

        preparedStatement.setLong(1, 2);
        preparedStatement.setString(2, "Gheyme");
        preparedStatement.setString(3, "100000T");

        preparedStatement.setLong(1, 3);
        preparedStatement.setString(2, "Kebab");
        preparedStatement.setString(3, "150000T");

        preparedStatement.setLong(1, 4);
        preparedStatement.setString(2, "Mirzaghasemi");
        preparedStatement.setString(3, "90000T");

        preparedStatement.setLong(1, 5);
        preparedStatement.setString(2, "Rice");
        preparedStatement.setString(3, "40000T");

        preparedStatement.executeUpdate();
        return null;
    }

    public UserRepo foods_order(UserEntity userEntity) throws Exception{
        preparedStatement = connection.prepareStatement("insert into customer (id_of_food, price) values (?, ?)");

        preparedStatement.setLong(1, userEntity.getId_Of_Food());
        preparedStatement.setString(2, userEntity.getPrice());

        preparedStatement.setLong(1, userEntity.getId_Of_Food());
        preparedStatement.setString(2, userEntity.getPrice());

        preparedStatement.executeUpdate();
        return null;
    }

    @Override
    public void close() throws Exception {
        preparedStatement.close();
        connection.close();
    }
}
