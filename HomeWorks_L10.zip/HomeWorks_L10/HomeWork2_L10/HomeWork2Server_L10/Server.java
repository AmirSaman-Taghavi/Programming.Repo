import userinterface.UserProcess;
import userinterface.controller.UserControl;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

public class Server {
    public static void main(String[] args) {
        UserControl userControl = new UserControl();
        userControl.control();
        try {
            System.out.println("Sever is pending...");
            LocateRegistry.createRegistry(1100);
            UserProcess userProcess = new UserProcess();
            Naming.rebind("Customer", userProcess);
        } catch (RemoteException rE) {
            rE.getStackTrace();
        } catch (MalformedURLException mE) {
            mE.getStackTrace();
        } catch (Exception e) {
            e.getStackTrace();
        }
    }
}
