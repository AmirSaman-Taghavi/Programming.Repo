package userinterface;

import userinterface.model.entity.UserEntity;
import userinterface.model.repository.UserRepo;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class UserProcess extends UnicastRemoteObject implements UserInterface{

    public UserProcess() throws RemoteException {
    }

    @Override
    public void takeAFood(UserRepo userRepo) throws Exception{
        userRepo.foods_Table();
        userRepo.foods_order(new UserEntity());
    }
}
