package userinterface;

import userinterface.model.repository.UserRepo;

import java.rmi.Remote;

public interface UserInterface extends Remote {
    void takeAFood(UserRepo userRepo) throws Exception;
}
