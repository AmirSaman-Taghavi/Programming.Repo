package bankinterface;

import bankinterface.model.entity.BankEntity;

import java.rmi.server.UnicastRemoteObject;

public class BankProcess extends UnicastRemoteObject implements BankInterface {
    public BankProcess() throws Exception {}


    @Override
    public int process1(BankEntity bankEntity) {
        bankEntity.getMoney();
        bankEntity.getWithdrawal();

        Object rm1 = bankEntity.getMoney() - bankEntity.getWithdrawal();
        return (int) rm1;
    }

    @Override
    public int process2(BankEntity bankEntity) {
        bankEntity.getMoney();
        bankEntity.getDeposit();

        Object rm2 = bankEntity.getMoney() - bankEntity.getDeposit();
        return (int) rm2;
    }
}
