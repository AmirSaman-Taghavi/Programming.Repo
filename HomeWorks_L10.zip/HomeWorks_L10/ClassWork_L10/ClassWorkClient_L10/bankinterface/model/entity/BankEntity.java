package bankinterface.model.entity;

public class BankEntity {
    private int money;
    private int withdrawal;
    private int deposit;

    public int getMoney() {
        return money;
    }

    public BankEntity setMoney(int money) {
        this.money = money;
        return this;
    }

    public int getWithdrawal() {
        return withdrawal;
    }

    public BankEntity setWithdrawal(int withdrawal) {
        this.withdrawal = withdrawal;
        return this;
    }

    public int getDeposit() {
        return deposit;
    }

    public BankEntity setDeposit(int deposit) {
        this.deposit = deposit;
        return this;
    }
}
