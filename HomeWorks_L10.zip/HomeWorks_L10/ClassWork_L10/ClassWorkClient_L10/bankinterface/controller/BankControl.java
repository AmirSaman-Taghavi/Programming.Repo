package bankinterface.controller;

import bankinterface.BankProcess;
import bankinterface.model.entity.BankEntity;

public class BankControl {
    public void control() {
        try {
            BankProcess bankProcess = new BankProcess();
            try {
                bankProcess.process1(new BankEntity());
            } catch (Exception e) {
                e.getStackTrace();
            }

            try {
                bankProcess.process2(new BankEntity());
            } catch (Exception e) {
                e.getStackTrace();
            }
        } catch (Exception e) {
            e.getStackTrace();
        }
    }
}
