package bankinterface;

import bankinterface.model.entity.BankEntity;

import java.rmi.Remote;

public interface BankInterface extends Remote {
    int process1(BankEntity bankEntity);
    int process2(BankEntity bankEntity);
}
