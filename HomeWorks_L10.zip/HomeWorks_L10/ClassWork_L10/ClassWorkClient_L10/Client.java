import bankinterface.BankInterface;
import bankinterface.model.entity.BankEntity;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class Client {
    public static void main(String[] args) {
        try {
            System.out.println("Starting...");
            BankInterface bankInterface = (BankInterface) Naming.lookup("//localhost/Bank");
            System.out.format("The remaining amount in the bank account: ", bankInterface.process1(new BankEntity()
                .setMoney(1000000).setWithdrawal(450000)));
            System.out.format("The remaining amount in the bank account: ", bankInterface.process2(new BankEntity()
                .setMoney(1000000).setDeposit(8000000)));
        } catch (NotBoundException nE) {
            nE.getStackTrace();
        } catch (MalformedURLException mE) {
            mE.getStackTrace();
        } catch (RemoteException rE) {
            rE.getStackTrace();
        } catch (Exception e) {
            e.getStackTrace();
        }
    }
}
