import bankinterface.BankProcess;
import bankinterface.controller.BankControl;
import bankinterface.model.entity.BankEntity;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

public class Server {
    public static void main(String[] args) {
        try {
            System.out.println("Server is pending...");
            BankControl bankControl = new BankControl();
            bankControl.control();
            LocateRegistry.createRegistry(1099);
            BankProcess bankProcess = new BankProcess();
            bankProcess.process1(new BankEntity());
            bankProcess.process2(new BankEntity());
            Naming.rebind("Bank", bankProcess);
        } catch (RemoteException rE) {
            rE.getStackTrace();
        } catch (MalformedURLException mE) {
            mE.getStackTrace();
        } catch (Exception e) {
            e.getStackTrace();
        }
    }
}
