package userinterface.model.entity;

public class UserEntity {
    private String name_Surname;
    private String gmail;
    private String city;
    private String username;
    private String password;

    public int getAge() {
        return age;
    }

    public UserEntity setAge(int age) {
        this.age = age;
        return this;
    }

    private int age;

    private String gender;
    private String date_Of_Birth;

    public String getName_Surname() {
        return name_Surname;
    }

    public UserEntity setName_Surname(String name_Surname) {
        this.name_Surname = name_Surname;
        return this;
    }

    public String getGmail() {
        return gmail;
    }

    public UserEntity setGmail(String gmail) {
        this.gmail = gmail;
        return this;
    }

    public String getCity() {
        return city;
    }

    public UserEntity setCity(String city) {
        this.city = city;
        return this;
    }

    public String getGender() {
        return gender;
    }

    public UserEntity setGender(String gender) {
        this.gender = gender;
        return this;
    }

    public String getDate_Of_Birth() {
        return date_Of_Birth;
    }

    public UserEntity setDate_Of_Birth(String date_Of_Birth) {
        this.date_Of_Birth = date_Of_Birth;
        return this;
    }

    public String getUsername() {
        return username;
    }

    public UserEntity setUsername(String username) {
        this.username = username;
        return this;
    }

    public String getPassword() {
        return password;
    }

    public UserEntity setPassword(String password) {
        this.password = password;
        return this;
    }
}
