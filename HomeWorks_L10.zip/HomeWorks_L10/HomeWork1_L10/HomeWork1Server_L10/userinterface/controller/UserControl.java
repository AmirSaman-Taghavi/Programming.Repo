package userinterface.controller;

import userinterface.UserProcess;
import userinterface.model.repository.UserDataBase;

public class UserControl {
    public void control() {
        try {
            UserDataBase userDataBase = new UserDataBase();
            try {
                userDataBase.dataBase();
            } catch (Exception e) {
                e.getStackTrace();
            }
        } catch (Exception e) {
            e.getStackTrace();
        }
        try {
            UserProcess userProcess = new UserProcess();
            try {
                userProcess.account(new UserDataBase());
            } catch (Exception e) {
                e.getStackTrace();
            }
        } catch (Exception e) {
            e.getStackTrace();
        }

        try {
            UserProcess userProcess = new UserProcess();
            try {
                userProcess.userName(new UserDataBase());
            } catch (Exception e) {
                e.getStackTrace();
            }
        } catch(Exception e) {
            e.getStackTrace();
        }

        try {
            UserProcess userProcess = new UserProcess();
            try {
                userProcess.password(new UserDataBase());
            } catch (Exception e) {
                e.getStackTrace();
            }
        } catch (Exception e) {
            e.getStackTrace();
        }
    }
}
