import userinterface.controller.UserControl;
import userinterface.UserProcess;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.*;

public class Server {
    public static void main(String[] args) {
        UserControl userControl = new UserControl();
        userControl.control();
        try {
            System.out.println("Server is pending...");
            LocateRegistry.createRegistry(1099);
            UserProcess userProcess = new UserProcess();
            Naming.rebind("Information", userProcess);
        } catch (RemoteException rE) {
            rE.getStackTrace();
        } catch (ServerNotActiveException sE) {
            sE.getStackTrace();
        } catch (MalformedURLException mE) {
            mE.getStackTrace();
        } catch (Exception e) {
            e.getStackTrace();
        }
    }
}
