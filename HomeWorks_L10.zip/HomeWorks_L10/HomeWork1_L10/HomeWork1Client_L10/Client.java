import userinterface.UserInterface;
import userinterface.controller.UserControl;
import userinterface.model.entity.UserEntity;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;


public class Client {
    public static void main(String[] args) {
        UserControl userControl = new UserControl();
        userControl.control();
        try {
            System.out.println("Starting...");
            UserInterface userInterface = (UserInterface) Naming.lookup("//localhost/Information");
            UserEntity userEntity = new UserEntity();
            userEntity.setName_Surname("Ali Bagheri");
            userEntity.setGmail("alibagheri007@gamil.com");
            userEntity.setCity("Isfahan");
            userEntity.setUsername("BagheMozafar");
            userEntity.setPassword("DamavandMountain");
            userEntity.setAge(25);
            userEntity.setGender("Male");
            userEntity.setDate_Of_Birth("1375/06/21");

            userEntity.setUsername("ShabhayeBarare");
            userEntity.setGender("Male");

            userEntity.setPassword("NiagaraWaterfall");
            userEntity.setCity("Isfahan");

            System.out.println(userEntity.getName_Surname());
            System.out.println(userEntity.getGmail());
            System.out.println(userEntity.getCity());
            System.out.println(userEntity.getUsername());
            System.out.println(userEntity.getPassword());
            System.out.println(userEntity.getAge());
            System.out.println(userEntity.getGender());
            System.out.println(userEntity.getDate_Of_Birth());
        } catch (NotBoundException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (RemoteException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.getStackTrace();
        }
    }
}