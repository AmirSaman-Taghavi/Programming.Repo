package userinterface;

import userinterface.model.entity.UserEntity;
import userinterface.model.repository.UserDataBase;

import java.rmi.server.UnicastRemoteObject;

public class UserProcess extends UnicastRemoteObject implements UserInterface {
    public UserProcess() throws Exception {}

    @Override
    public void account(UserDataBase userDataBase) throws Exception {
        userDataBase.dataEntry(new UserEntity());
    }

    @Override
    public void userName(UserDataBase userDataBase) throws Exception {
        userDataBase.alter_Username(new UserEntity());
    }

    @Override
    public void password(UserDataBase userDataBase) throws Exception {
        userDataBase.alter_Password(new UserEntity());
    }
}
