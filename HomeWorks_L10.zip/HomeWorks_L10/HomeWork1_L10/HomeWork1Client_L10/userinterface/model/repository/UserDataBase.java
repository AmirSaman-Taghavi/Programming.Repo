package userinterface.model.repository;

import userinterface.model.entity.UserEntity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class UserDataBase {
    private Connection connection;
    private PreparedStatement preparedStatement;
    public void dataBase() throws Exception{
        Class.forName("oracle.jdbc.driver.OracleDriver");
        connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "user1",
            "samrod82");
    }

    public void dataEntry(UserEntity userEntity) throws Exception{
        preparedStatement = connection.prepareStatement("insert into user1 (name_surname, gmail, city, username, " +
            "password, age, gender, date_of_birth) values (?, ?, ?, ?, ?, ?, ?, ?)");
        preparedStatement.setString(1, userEntity.getName_Surname());
        preparedStatement.setString(2, userEntity.getGmail());
        preparedStatement.setString(3, userEntity.getCity());
        preparedStatement.setString(4, userEntity.getUsername());
        preparedStatement.setString(5, userEntity.getPassword());
        preparedStatement.setLong(6, userEntity.getAge());
        preparedStatement.setString(7, userEntity.getGender());
        preparedStatement.setString(8, userEntity.getDate_Of_Birth());
        preparedStatement.executeUpdate();
    }

    public void alter_Username(UserEntity userEntity) throws Exception {
        preparedStatement = connection.prepareStatement("update user1 set username = ? where gender = ?");
        preparedStatement.setString(1, userEntity.getUsername());
        preparedStatement.setString(2, userEntity.getGender());
        preparedStatement.executeUpdate();
    }

    public void alter_Password(UserEntity userEntity) throws Exception{
        preparedStatement = connection.prepareStatement("update user1 set password = ? where city = ?");
        preparedStatement.setString(1, userEntity.getPassword());
        preparedStatement.setString(2, userEntity.getCity());
        preparedStatement.executeUpdate();
    }
}
