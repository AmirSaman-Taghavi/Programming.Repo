package userinterface;

import userinterface.model.repository.UserDataBase;

import java.rmi.Remote;

public interface UserInterface extends Remote {
    void account(UserDataBase userDataBase) throws Exception;
    void userName(UserDataBase userDataBase) throws Exception;
    void password(UserDataBase userDataBase) throws Exception;
}
