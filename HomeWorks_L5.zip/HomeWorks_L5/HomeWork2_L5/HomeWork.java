public class HomeWork {
    public static void main(String[] Args) {
        UserRegistration.getInstance().Information("AmirSamanTaghavi", "Tehran", "1382/02/25", "samanTZx", "09309604211");
    }
}
