public class UserRegistration {
    public static UserRegistration userRegistration = new UserRegistration();
    public static UserRegistration getInstance() {return userRegistration;}
    private UserRegistration(){}
    public void Information(String name, String city, String dateOfBirth, String password, String phoneNumber) {
        System.out.println(name);
        System.out.println(city);
        System.out.println(dateOfBirth);
        System.out.println(password);
        System.out.println(phoneNumber);
    }
}
