public interface Calculation {
    String p = "+";
    String m = "-";
    void calc(String s, double d1, double d2);
}