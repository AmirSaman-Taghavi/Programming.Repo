public class Calculate implements Calculation {
    @Override
    public void calc(String s, double d1, double d2){

    }
    public static Calculation calculate(String s, double d1, double d2){
        switch (s) {
            case "+":
                new CalcPlus().calc(s, d1, d2);
                break;
            case "-":
                new CalcMinus().calc(s, d1, d2);
                break;
        }
        return null;
    }
}
