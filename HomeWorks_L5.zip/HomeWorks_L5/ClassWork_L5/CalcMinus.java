public class CalcMinus extends Calculate{
    @Override
    public void calc(String s, double d1, double d2) {
        double d = d1 - d2;
        System.out.println(d);
    }
}
