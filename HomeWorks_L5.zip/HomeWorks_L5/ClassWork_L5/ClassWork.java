import java.util.Scanner;

public class ClassWork {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter first number: ");
        double d1 = in.nextDouble();

        System.out.print("Enter character: ");
        String s = in.next();

        System.out.print("Enter second number: ");
        double d2 = in.nextDouble();

        try {
            Calculation calculation = Calculate.calculate(s, d1, d2);
            calculation.calc(s, d1, d2);
        } catch (NullPointerException npe) {
            System.out.println("End of Calculating");
        }
    }
}
