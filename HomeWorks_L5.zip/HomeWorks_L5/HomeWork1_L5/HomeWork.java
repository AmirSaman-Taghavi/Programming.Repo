import java.nio.charset.StandardCharsets;

public class HomeWork {
    public static void main(String[] args) {
        User user = new User().setUsername("AMTZ82").setName("AmirSamanTaghavi").setPassword("4001234105***").
                setAge(18).
                setAddress("Shariati St, Motahari St, Tehranchi All, 28 Nu, 8 U").
                setPhoneNumber("09309602582").setDegreeOfEducation("Bachelor");
        System.out.println(user.getUsername());
        System.out.println(user.getName());
        System.out.println(user.getPassword());
        System.out.println(user.getAge());
        System.out.println(user.getAddress());
        System.out.println(user.getPhoneNumber());
        System.out.println(user.getDegreeOfEducation());
    }
}
