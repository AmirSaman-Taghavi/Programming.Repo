public class Saipa implements CarSpecifications{
    @Override
    public void carSpecification() {
        String yearOfConstruction = "1398";
        String typeOfCar = "Passenger";
        String name = "Quick";
        String color = "Black";
        System.out.println(yearOfConstruction);
        System.out.println(typeOfCar);
        System.out.println(name);
        System.out.println(color);
    }
}
