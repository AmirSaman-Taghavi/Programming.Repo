public class Car {
    public static CarSpecifications cars(String car) {
        switch (car) {
            case "IranKhodro":
                return new IranKhodro();
            case "Saipa":
                return new Saipa();
        }
        return null;
    }
}
