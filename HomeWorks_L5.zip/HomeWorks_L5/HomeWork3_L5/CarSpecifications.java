public interface CarSpecifications {
      String IKh = "IranKhodro";
      String Sai = "Saipa";
      void carSpecification();
}
