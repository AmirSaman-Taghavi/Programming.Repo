public class IranKhodro implements CarSpecifications{
    @Override
    public void carSpecification() {
        String yearOfConstruction = "1399";
        String typeOfCar = "Passenger";
        String name = "Dena";
        String color = "White";
        System.out.println(yearOfConstruction);
        System.out.println(typeOfCar);
        System.out.println(name);
        System.out.println(color);
    }
}
