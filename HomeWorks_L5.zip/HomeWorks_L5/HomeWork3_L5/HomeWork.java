public class HomeWork {
    public static void main(String[] args) {
        CarSpecifications carSpecifications = Car.cars("IranKhodro");
        carSpecifications.carSpecification();

        System.out.println();

        carSpecifications = Car.cars("Saipa");
        carSpecifications.carSpecification();
    }
}
