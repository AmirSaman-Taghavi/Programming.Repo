public class Equation {
    public void eq(double a, double d, double b, double c, double e, double f) {
        double Q = a*d - b*c;
        if (Q == 0){
            System.out.print("The equation has no answer.");
        } else{
           double W = e*d - b*f;
           double G = a*f - e*c;

           double X = W/Q;
           double Y = G/Q;
           if (W == 0){
              System.out.print("X = 0");
           }
           else if (G == 0){
               System.out.print("Y = 0");
           }

           else{
               System.out.format("X = %f\n", X);
               System.out.format("Y = %f\n", Y);
           }
        }
    }
}
