public class HomeWorld {
    public static void main(String[] args){
        Bookstore bookstore = new Bookstore();
        bookstore.restoration();

        bookstore.borrow();

        bookstore.to_Be_Quiet();

        System.out.print("---------------------------------------------");
    }
}
