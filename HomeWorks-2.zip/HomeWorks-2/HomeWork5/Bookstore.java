public class Bookstore {
    public void borrow(){

        System.out.print("This book have been borrowed.\n\n");}

    public void restoration(){
        System.out.print("Please restore this book correctly and safely.\n\n");
    }

    public void to_Be_Quiet(){
        System.out.print("Please be quiet while reading in the library.\n");
    }
}
