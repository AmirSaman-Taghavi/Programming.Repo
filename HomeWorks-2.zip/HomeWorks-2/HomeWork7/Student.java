public class Student {
    public void st_Grade(float p, float m, float c, int np, int nm, int nc){
        float physics = np * p;
        System.out.format("Physics grade with coefficient= %f\n", physics);

        float mathematics = nm * m;
        System.out.format("Mathematics grade with coefficient= %f\n", mathematics);

        float computer = nc * c;
        System.out.format("Computer grade with coefficient= %f\n\n", computer);

        int g = 3;
        double average = (physics + mathematics + computer) / g;
        System.out.format("Average student grades = %f\n", average);
        if(average >= 11 && average < 12)
                System.out.print("You have gotten a conditional grade point average!");
    }
}
