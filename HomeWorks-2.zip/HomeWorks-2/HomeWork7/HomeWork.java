import java.util.Scanner;
public class HomeWork {
    public static void main(String[] args) {
        Student student = new Student();
        Scanner input = new Scanner(System.in);

        System.out.print("Enter Physics grade: ");
        float p = input.nextFloat();
        System.out.print("Enter Mathematics grade: ");
        float m = input.nextFloat();
        System.out.print("Enter Computer grade: ");
        float c = input.nextFloat();

        System.out.println();

        System.out.print("Enter Physics coefficient: ");
        int np = input.nextInt();
        System.out.print("Enter Mathematics coefficient: ");
        int nm = input.nextInt();
        System.out.print("Enter Computer coefficient: ");
        int nc = input.nextInt();

        System.out.println();

        student.st_Grade(p, m, c, np, nm, nc);
    }
}
