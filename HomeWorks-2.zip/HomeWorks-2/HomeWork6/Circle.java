import java.util.*;
public class Circle {
    public void ci_Perimeter(double r) {
        double perimeter = 2 * Math.PI * r;
        System.out.format("Perimeter = %f\n", perimeter);
    }

    public void ci_Area(double r) {
        double area = Math.PI * r * r;
        System.out.format("Area = %f\n", area);
    }
}
