import java.util.Scanner;

public class HomeWork {
    public static void main(String[] args){
        Square square = new Square();
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the length of the side of a square: ");
        double p = input.nextDouble();

        square.sq_Perimeter(p);
        square.sq_Area(p);

        Rectangle rectangle = new Rectangle();
        System.out.print("Enter the length of a rectangle: ");
        double l = input.nextDouble();
        System.out.print("Enter the width of a rectangle: ");
        double w = input.nextDouble();

        rectangle.re_Perimeter(l, w);
        rectangle.re_Area(l, w);

        Circle circle = new Circle();
        System.out.print("Enter radius: ");
        double r = input.nextDouble();

        circle.ci_Perimeter(r);
        circle.ci_Area(r);



    }
}
