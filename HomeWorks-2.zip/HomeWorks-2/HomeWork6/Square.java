import java.util.*;
public class Square {
    public void sq_Perimeter(double p) {
        double perimeter = 4 * p;
        System.out.format("Perimeter = %f\n",perimeter);
    }

    public void sq_Area(double p) {
        double area = p * p;
        System.out.format("Area = %f\n\n",area);
    }
}