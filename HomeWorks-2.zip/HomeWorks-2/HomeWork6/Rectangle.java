import java.util.Scanner;
public class Rectangle {
    public void re_Perimeter(double l, double w) {
        double perimeter = 2 * (l + w);
        System.out.format("Perimeter = %f\n", perimeter);
    }

    public void re_Area(double l, double w) {
        double area = l * w;
        System.out.format("Area = %f\n\n", area);
    }
}
