import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

@Path("/students")
public class HomeWork {
    //http://localhost:80/rest/students/information?Name=AliReza&Surname=Monadi&Student number=40012341982381&General math 2 score=18.25&Physics 2 score=17.50&Advanced programming score=19.75
    //http://localhost:80/rest/students/information?Name=Shahab&Surname=Safaryan&Student number=40012346209731&General math 2 score=17.75& Physics 2 score=15.25&Advanced programming score=20
    //http://localhost:80/rest/students/information?Name=Sergio&Surname=Moreno&Student number=4001234971853&General math 2 score=19.75&Physics 2 score=18.75&Advanced programming score=19.50
    @Path("/set_Information")
    @GET
    @Produces("text/pain")
    public static void main(String[] args) {
        JSONObject jsonObject1 = new JSONObject();
        jsonObject1.put("Name", "AliReza");
        jsonObject1.put("Surname", "Monadi");
        jsonObject1.put("Student number", "40012341982381");
        jsonObject1.put("General math 2 score: ", "18.25");
        jsonObject1.put("Physics 2 score: ", "17.50");
        jsonObject1.put("Advanced programming score: ", "19.75");

        System.out.println("The first student: " + jsonObject1.toJSONString());
        System.out.println("\n");

        JSONObject jsonObject2 = new JSONObject();
        jsonObject2.put("Name", "Shahab");
        jsonObject2.put("Surname", "Safaryan");
        jsonObject2.put("Student number", "40012346209731");
        jsonObject2.put("General math 2 score: ", "17.75");
        jsonObject2.put("Physics 2 score: ", "15.25");
        jsonObject2.put("Advanced programming score: ", "20");

        System.out.println("The second student: " + jsonObject1.toJSONString());
        System.out.println("\n");

        JSONObject jsonObject3 = new JSONObject();
        jsonObject3.put("Name", "Sergio");
        jsonObject3.put("Surname", "Moreno");
        jsonObject3.put("Student number", "4001234971853");
        jsonObject3.put("General math 2 score: ", "19.75");
        jsonObject3.put("Physics 2 score: ", "18.75");
        jsonObject3.put("Advanced programming score: ", "19.50");

        System.out.println("The third student: " + jsonObject1.toJSONString());
        System.out.println("\n");

        JSONArray jsonArray1 = new JSONArray();
        jsonArray1.add(jsonObject1);
        jsonArray1.add(jsonObject2);
        jsonArray1.add(jsonObject3);

        System.out.println("Students: " + jsonArray1.toJSONString());
        System.out.println("\n");
    }
    public JSONArray set_Information (@QueryParam("Name") String name, @QueryParam("Surname") String surName, @QueryParam("Student number") long studentNumber,
            @QueryParam("General math 2 score") float generalMath2Score, @QueryParam("Physics 2 score") float physics2Score,
            @QueryParam("Advanced programming score") float advancedProgrammingScore) {

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("Name", name);
        jsonObject.put("Surname", surName);
        jsonObject.put("Student number", studentNumber);
        jsonObject.put("General math 2 score: ", generalMath2Score);
        jsonObject.put("Physics 2 score: ", physics2Score);
        jsonObject.put("Advanced programming score: ", advancedProgrammingScore);

        JSONArray jsonArray = new JSONArray();
        jsonArray.add(jsonObject);

        return jsonArray;
    }
}
