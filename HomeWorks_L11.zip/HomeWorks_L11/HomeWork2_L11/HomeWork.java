import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

@Path("/universities")
public class HomeWork {
    //http://localhost:80/rest/universities/informationOfUniversities?University name=University of Tehran&Number of students=30000&Major1=Psychology&Major2=Computer Engineering&Major3=Biomedical Engineering
    //http://localhost:80/rest/universities/informationOfUniversities?University name=Sharif University of Technology&Number of students=25000&Major1=Electrical Engineering&Major2=Computer Engineering&Major3=Mechanic Engineering
    //http://localhost:80/rest/universities/informationOfUniversities?University name=Amirkabir University&Number of students=25000&Major1=Economy&Major2=Computer Science&Major3=Computer Engineering
    //http://localhost:80/rest/universities/informationOfUniversities?University name=KhajeNasireAldinTosi University&Number of students=35000&Major1=Agricultural Engineering&Major2=Computer Engineering&Major3=Petroleum Engineering
    //http://localhost:80/rest/universities/informationOfUniversities?University name=Shahid Beheshti University&Number of students=40000&Major1=Theology&Major2=Dental&Major3=Computer Engineering
    @Path("/et_University_Information")
    @GET
    @Produces("text/pain")
    public static void main(String[] args) {
        JSONObject jsonObject1 = new JSONObject();
        jsonObject1.put("University name", "University of Tehran");
        jsonObject1.put("Number of students", "30000");
        jsonObject1.put("Major1", "Psychology");
        jsonObject1.put("Major2", "Computer Engineering");
        jsonObject1.put("Major3", "Biomedical Engineering");

        System.out.println("The first university: " + jsonObject1.toJSONString());
        System.out.println("\n");

        JSONObject jsonObject2 = new JSONObject();
        jsonObject2.put("University name", "Sharif University of Technology");
        jsonObject2.put("Number of students", "25000");
        jsonObject2.put("Major1", "Electrical Engineering");
        jsonObject2.put("Major2", "Computer Engineering");
        jsonObject2.put("Major3", "Mechanic Engineering");

        System.out.println("The second university: " + jsonObject2.toJSONString());
        System.out.println("\n");

        JSONObject jsonObject3 = new JSONObject();
        jsonObject3.put("University name", "Amirkabir University");
        jsonObject3.put("Number of students", "25000");
        jsonObject3.put("Major1", "Economy");
        jsonObject3.put("Major2", "Computer Science");
        jsonObject3.put("Major3", "Computer Engineering");

        System.out.println("The third university: " + jsonObject3.toJSONString());
        System.out.println("\n");

        JSONObject jsonObject4 = new JSONObject();
        jsonObject4.put("University name", "KhajeNasireAldinTosi University");
        jsonObject4.put("Number of students", "35000");
        jsonObject4.put("Major1", "Agricultural Engineering");
        jsonObject4.put("Major2", "Computer Engineering");
        jsonObject4.put("Major3", "Petroleum Engineering");

        System.out.println("The forth university: " + jsonObject4.toJSONString());
        System.out.println("\n");

        JSONObject jsonObject5 = new JSONObject();
        jsonObject5.put("University name", "Shahid Beheshti University");
        jsonObject5.put("Number of students", "40000");
        jsonObject5.put("Major1", "Theology");
        jsonObject5.put("Major2", "Dental");
        jsonObject5.put("Major3", "Chemical Engineering");

        System.out.println("The fifth university: " + jsonObject5.toJSONString());
        System.out.println("\n");

        JSONArray jsonArray1 = new JSONArray();
        jsonArray1.add(jsonObject1);
        jsonArray1.add(jsonObject2);
        jsonArray1.add(jsonObject3);
        jsonArray1.add(jsonObject4);
        jsonArray1.add(jsonObject5);

        System.out.println("Universities: " + jsonArray1.toJSONString());
        System.out.println("\n");
    }
    public JSONArray set_University_Information(@QueryParam("University name") String universityName, @QueryParam("Number of Students") long numberOfStudents
    , @QueryParam("Major1") String major1, @QueryParam("Major2") String major2, @QueryParam("Major3") String major3) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("University name", universityName);
        jsonObject.put("Number of students", numberOfStudents);
        jsonObject.put("Major1", major1);
        jsonObject.put("Major2", major2);
        jsonObject.put("Major3", major3);

        JSONArray jsonArray = new JSONArray();
        jsonArray.add(jsonObject);

        return jsonArray;
    }
}
