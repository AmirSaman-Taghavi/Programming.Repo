package main.java.com.example.classwork_l11;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

@Path("/employees")
public class ClassWork {
    //http://localhost:80/rest/employees/set_Information?Name=Ali&Surname=YazdanPanah&Phone number=09128751209&Home phone number=22139834&National code=0236512749&Date of birth=1361/02/30&Employee job position=General Manager&Income=6000000
    //http://localhost:80/rest/employees/set_Information?Name=Mohammad&Surname=Yosefi&Phone number=09195628120&Home phone number=77290712&National code=0975627426&Date of birth=1364/09/15&Employee job position=General Manager&Income=3500000
    //http://localhost:80/rest/employees/set_Information?Name=Romina&Surname=Khanzade&Phone number=09154908269&Home phone number=66231098&National code=081823921&Date of birth=1363/11/17&Employee job position=General Manager&Income=1000000
    @Path("/set_Information")
    @GET
    @Produces("text/plain")
    public static void main(String[] args) {
        JSONObject jsonObject1 = new JSONObject();
        jsonObject1.put("Name", "Ali");
        jsonObject1.put("Surname", "YazdanPanah");
        jsonObject1.put("Phone number", "09128751209");
        jsonObject1.put("Home phone number", "22139834");
        jsonObject1.put("National code", "0236512749");
        jsonObject1.put("Date of birth", "1361/02/30");
        jsonObject1.put("Employee job position", "General Manager");
        jsonObject1.put("Income", "6000000");

        System.out.println("The first employee: " + jsonObject1.toJSONString());
        System.out.println("\n");

        JSONObject jsonObject2 = new JSONObject();
        jsonObject2.put("Name", "Mohammad");
        jsonObject2.put("Surname", "Yosefi");
        jsonObject2.put("Phone number", "09195628120");
        jsonObject2.put("Home phone number", "77290712");
        jsonObject2.put("National code", "0975627426");
        jsonObject2.put("Date of birth", "1364/09/15");
        jsonObject2.put("Employee job position", "Department Manager");
        jsonObject2.put("Income", "3500000");

        System.out.println("The second employee: " + jsonObject2.toJSONString());
        System.out.println("\n");

        JSONObject jsonObject3 = new JSONObject();
        jsonObject3.put("Name", "Romina");
        jsonObject3.put("Surname", "Khanzade");
        jsonObject3.put("Phone number", "09154908269");
        jsonObject3.put("Home phone number", "66231098");
        jsonObject3.put("National code", "081823921");
        jsonObject3.put("Date of birth", "1363/11/17");
        jsonObject3.put("Employee job position", "Simple employee");
        jsonObject3.put("Income", "1000000");

        System.out.println("The third employee: " + jsonObject3.toJSONString());
        System.out.println("\n");

        JSONArray jsonArray1 = new JSONArray();
        jsonArray1.add(jsonObject1);
        jsonArray1.add(jsonObject2);
        jsonArray1.add(jsonObject3);

        System.out.println("Employees: " + jsonObject1.toJSONString());
        System.out.println("\n");
    }
    public String set_Information(@QueryParam("Name") String name, @QueryParam("Surname") String surName, @QueryParam("Phone number") long phoneNumber,
                                  @QueryParam("Home phone number") long homePhoneNumber, @QueryParam("National code") long nationalCode, @QueryParam("Date of birth") String
                  dateOfBirth, @QueryParam("Employee job position") String employeeJobPosition, @QueryParam("Income") long income) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("Name", name);
        jsonObject.put("Surname", surName);
        jsonObject.put("Phone number", phoneNumber);
        jsonObject.put("Home phone number", homePhoneNumber);
        jsonObject.put("National code", nationalCode);
        jsonObject.put("Date of birth", dateOfBirth);
        jsonObject.put("Employee job position", employeeJobPosition);
        jsonObject.put("Income", income);

        JSONArray jsonArray1 = new JSONArray();
        jsonArray1.add(jsonObject);

        System.out.println("Employees: " + jsonObject.toJSONString());
        System.out.println("\n");
        return jsonArray1.toJSONString();
    }

}