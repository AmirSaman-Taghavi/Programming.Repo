import java.sql.*;

public class HomeWork {
    public static void main(String[] args) {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@LAPTOP-UPV59LDR:1521:xe", "amin",
                "samrod82");
            PreparedStatement preparedStatement1 = connection.prepareStatement("insert into person(Usercode, Username, Email, "
                    + "Password, Age, Educationrate, id) values (?, ?, ?, ?, ?, ?, ?)");
            preparedStatement1.setString(1, "40002065");
            preparedStatement1.setString(2, "mehranmo");
            preparedStatement1.setString(3, "meharnrahmanii");
            preparedStatement1.setString(4, "manai09");
            preparedStatement1.setLong(5, 45);
            preparedStatement1.setString(6, "PHD");
            preparedStatement1.setLong(7, 1);
            System.out.println("insert into DB:" + preparedStatement1.executeUpdate());

            PreparedStatement preparedStatement2 = connection.prepareStatement("insert into person(Usercode, Username, Email, "
                    + "Password, Age, Educationrate, id) values (?, ?, ?, ?, ?, ?, ?)");
            preparedStatement2.setString(1, "99231254");
            preparedStatement2.setString(2, "ashk678");
            preparedStatement2.setString(3, "ashkanmote");
            preparedStatement2.setString(4, "uvf300");
            preparedStatement2.setLong(5, 22);
            preparedStatement2.setString(6, "Undergraduate");
            preparedStatement2.setLong(7, 2);
            System.out.println("insert into DB:" + preparedStatement2.executeUpdate());

            PreparedStatement preparedStatement3 = connection.prepareStatement("insert into person(Usercode, Username, Email, " +
                    "Password, Age, Educationrate, id) values (?, ?, ?, ?, ?, ?, ?)");
            preparedStatement3.setString(1, "51239573");
            preparedStatement3.setString(2, "sarau90");
            preparedStatement3.setString(3, "newlogic");
            preparedStatement3.setString(4, "saramah61");
            preparedStatement3.setLong(5, 26);
            preparedStatement3.setString(6, "Master's degree");
            preparedStatement3.setLong(7, 3);
            System.out.println("insert into DB:" + preparedStatement3.executeUpdate());

            PreparedStatement preparedStatement4 = connection.prepareStatement("update person set age = ? where id >= ?");
            preparedStatement4.setLong(1, 45);
            preparedStatement4.setLong(2, 2);

            preparedStatement1.close();
            preparedStatement2.close();
            preparedStatement3.close();
            preparedStatement4.close();
            connection.close();
        } catch (ClassNotFoundException ce) {
            System.out.println("DB driver not exist!");
        } catch (SQLException se) {
            System.out.println("DB error : " + se.getMessage());
        }
    }
}
