import java.sql.*;
import java.util.Scanner;

public class HomeWork {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        try{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@LAPTOP-UPV59LDR:1521:xe", "amir",
                "samrod82");
            PreparedStatement preparedStatement01 = connection.prepareStatement("insert into employee(emk, name, enc, fname, "
                + "pe, inc, ye, id)values(?, ?, ?, ?, ?, ?, ?, ?)");
            preparedStatement01.setLong(1, 2001);
            preparedStatement01.setString(2, "ali");
            preparedStatement01.setLong(3, 10756);
            preparedStatement01.setString(4, "mohsen");
            preparedStatement01.setString(5, "simple employee");
            preparedStatement01.setLong(6, 2000000);
            preparedStatement01.setLong(7, 10);
            preparedStatement01.setLong(8, 1);
            System.out.println("insert into DB:" + preparedStatement01.executeUpdate());

           PreparedStatement preparedStatement02 = connection.prepareStatement("insert into employee(emk, name, enc, fname, "
               + "pe, inc, ye, id)values(?, ?, ?, ?, ?, ?, ?, ?)");
            preparedStatement02.setLong(1, 2002);
            preparedStatement02.setString(2, "farhad");
            preparedStatement02.setLong(3, 1344);
            preparedStatement02.setString(4, "hadi");
            preparedStatement02.setString(5, "head of department");
            preparedStatement02.setLong(6, 3500000);
            preparedStatement02.setLong(7, 19);
            preparedStatement02.setLong(8, 2);
            System.out.println("insert into DB:" + preparedStatement02.executeUpdate());

           PreparedStatement preparedStatement03 = connection.prepareStatement("insert into employee(emk, name, enc, fname, "
               + "pe, inc, ye, id)values(?, ?, ?, ?, ?, ?, ?, ?)");
            preparedStatement03.setLong(1, 2003);
            preparedStatement03.setString(2, "jamshid");
            preparedStatement03.setLong(3, 1262);
            preparedStatement03.setString(4, "gholamreza");
            preparedStatement03.setString(5, "janitor");
            preparedStatement03.setLong(6, 1000000);
            preparedStatement03.setLong(7, 6);
            preparedStatement03.setLong(8, 3);
            System.out.println("insert into DB:" + preparedStatement03.executeUpdate());

            System.out.print("Enter a string: ");
            String str = input.next();
            PreparedStatement preparedStatement1;
            PreparedStatement preparedStatement2;
            switch(str) {
                case "delete from employee where emk = 2001 and name = 'ali' and id = 1":
                    preparedStatement1 = connection.prepareStatement("delete from employee where emk = 2001 " +
                            "and " + "name = 'ali' and id = 1");
                    System.out.println("delete from DB:" + preparedStatement1.executeUpdate());
                    preparedStatement1.close();
                    break;
                case "delete from employee where inc = 3500000":
                    preparedStatement2 = connection.prepareStatement("delete from employee where " +
                            "inc = 3500000 or inc = 1000000");
                    System.out.println("delete from DB:" + preparedStatement2.executeUpdate());
                    preparedStatement2.close();
                    break;
                }
            preparedStatement01.close();
            preparedStatement02.close();
            preparedStatement03.close();
            connection.close();
        } catch (ClassNotFoundException ce) {
            System.out.println("DB driver not exist!");
        } catch (SQLException se) {
            System.out.println("DB error " + se.getMessage());
        }
    }
}
