import java.sql.*;
import java.util.Scanner;

public class HomeWork {
    public static void main(String[] args) {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@LAPTOP-UPV59LDR:1521:xe", "majid",
                "samrod82");
            PreparedStatement preparedStatement1 = connection.prepareStatement("insert into student(stc, n, y, g, id) " +
                "values (?, ?, ?, ?)");
            Scanner in = new Scanner(System.in);
            System.out.print("Enter student number(1): ");
            String str11 = in.next();

            System.out.print("Enter student name(1): ");
            String str12 = in.next();

            System.out.print("Enter entering year(1): ");
            int y1 = in.nextInt();

            System.out.print("Enter student final grade(1): ");
            float f1 = in.nextFloat();

            System.out.print("Enter student id(1): ");
            int id1 = in.nextInt();

            preparedStatement1.setString(1, str11);
            preparedStatement1.setString(2, str12);
            preparedStatement1.setLong(3, y1);
            preparedStatement1.setFloat(4, f1);
            preparedStatement1.setLong(5, id1);
            System.out.println("insert into DB: " + preparedStatement1.executeUpdate());

            PreparedStatement preparedStatement2 = connection.prepareStatement("insert into student(stc, n, y, g, id) " +
                    "values (?, ?, ?, ?)");
            System.out.print("Enter student number(2): ");
            String str21 = in.next();

            System.out.print("Enter student name(2): ");
            String str22 = in.next();

            System.out.print("Enter entering year(2): ");
            int y2 = in.nextInt();

            System.out.print("Enter student final grade(2): ");
            float f2 = in.nextFloat();

            System.out.print("Enter student id(2): ");
            int id2 = in.nextInt();

            preparedStatement2.setString(1, str21);
            preparedStatement2.setString(2, str22);
            preparedStatement2.setLong(3, y2);
            preparedStatement2.setFloat(4, f2);
            preparedStatement2.setLong(5, id2);
            System.out.println("insert into DB: " + preparedStatement2.executeUpdate());

            System.out.print("Enter a string:");
            String str = in.next();
                switch (str) {
                    case "delete from student where stc = 40012895402314":
                        PreparedStatement preparedStatement3 = connection.prepareStatement("delete from student" +
                                " where stc = 40012895402314");
                        System.out.println("delete from DB" + preparedStatement3.executeUpdate());
                        preparedStatement3.close();
                        break;
                    case "update student set g = 19.06 where y = 1399":
                        PreparedStatement preparedStatement4 = connection.prepareStatement("update student set g = 19.06" +
                                "where y = 1399");
                        System.out.println("update DB: " + preparedStatement4.executeUpdate());
                        preparedStatement4.close();
                    }
                    preparedStatement1.close();
                    preparedStatement2.close();
                    connection.close();
        } catch(ClassNotFoundException ce) {
            System.out.println("DB driver not exist!");
        } catch(SQLException se) {
            System.out.println("DB error: " + se.getMessage());
        }
    }
}
