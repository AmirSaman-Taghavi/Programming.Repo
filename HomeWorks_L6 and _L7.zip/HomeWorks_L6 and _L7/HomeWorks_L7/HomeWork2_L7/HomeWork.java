import controller.FactoCont;

public class HomeWork {
    public static void main(String[] args) {
        FactoCont factoCont = new FactoCont();
        factoCont.control();
    }
}
