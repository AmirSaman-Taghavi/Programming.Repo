package model.service;
import model.entity.FactoEntity;
import model.repository.FactoRepo;

public class FactoServ {
    private FactoServ() {

    }
    private static FactoServ factoServ = new FactoServ();

    public static FactoServ getInstance() {
        return factoServ;
    }

    public void extra(FactoEntity factoEntity) throws Exception {
        try(FactoRepo factoRepo = new FactoRepo()) {
            factoRepo.car(factoEntity);
            factoRepo.commit();
        }
    }

    public void chose(FactoEntity factoEntity) throws Exception {
        try(FactoRepo factoRepo = new FactoRepo()) {
            factoRepo.select(factoEntity);
            factoRepo.commit();
        }
    }
}
