package model.entity;

public class FactoEntity {
    private String car;
    private String color;
    private int year;
    private long price;
    private int id;

    public int getId() {
        return id;
    }

    public FactoEntity setId(int id) {
        this.id = id;
        return this;
    }

    public String getCar() {
        return car;
    }

    public FactoEntity setCar(String car) {
        this.car = car;
        return this;
    }

    public String getColor() {
        return color;
    }

    public FactoEntity setColor(String color) {
        this.color = color;
        return this;
    }

    public int getYear() {
        return year;
    }

    public FactoEntity setYear(int year) {
        this.year = year;
        return this;
    }

    public long getPrice() {
        return price;
    }

    public FactoEntity setPrice(long price) {
        this.price = price;
        return this;
    }
}
