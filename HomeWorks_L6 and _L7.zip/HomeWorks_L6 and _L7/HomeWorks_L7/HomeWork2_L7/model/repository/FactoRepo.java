package model.repository;
import model.entity.FactoEntity;
import java.sql.*;

public class FactoRepo implements AutoCloseable {
    private Connection connection;
    private PreparedStatement preparedStatement;
    private PreparedStatement preparedStatement1;
    private ResultSet resultSet;

    public FactoRepo() throws Exception{
        Class.forName ("oracle.jdbc.driver.OracleDriver");
        connection= DriverManager.getConnection ("jdbc:oracle:thin:@LAPTOP-UPV59LDR:1521:xe", "ivan",
                "samrod82");
        connection.setAutoCommit (false);
    }
    public void car(FactoEntity factoEntity) throws Exception {
        preparedStatement = connection.prepareStatement("insert into c(car, color, year, price, id)" +
                "values(?, ?, ? ,?, ?)");
        preparedStatement.setString(1, factoEntity.getCar());
        preparedStatement.setString(2, factoEntity.getColor());
        preparedStatement.setLong(3, factoEntity.getYear());
        preparedStatement.setLong(4, factoEntity.getPrice());
        preparedStatement.setLong(5, factoEntity.getId());
        preparedStatement.executeUpdate();

        preparedStatement1 = connection.prepareStatement("insert into c(car, color, year, price, id)" +
                "values(?, ?, ? ,?, ?)");
        preparedStatement1.setString(1,factoEntity.getCar());
        preparedStatement1.setString(2, factoEntity.getColor());
        preparedStatement1.setLong(3, factoEntity.getYear());
        preparedStatement1.setLong(4, factoEntity.getPrice());
        preparedStatement1.setLong(5, factoEntity.getId());
        preparedStatement1.executeUpdate();
    }

    public void select(FactoEntity factoEntity) throws Exception {
        preparedStatement = connection.prepareStatement("select * from c where id = 1");
        resultSet = preparedStatement.executeQuery();

        preparedStatement1 =  connection.prepareStatement("select * from c where color = 'black'");
        resultSet = preparedStatement1.executeQuery();
    }

    public void commit() throws Exception {
        connection.commit();
    }
    public void rollback() throws Exception {
        connection.rollback();
    }
    public void close() throws Exception {
        preparedStatement.close();
        connection.close();
    }
}
