package controller;
import model.entity.FactoEntity;
import model.service.FactoServ;

public class FactoCont {
    public void control() {
        try {
            FactoServ.getInstance().extra(new FactoEntity().setCar("pride").setColor("white").setYear(1382)
                .setPrice(26000000).setId(1));
            System.out.println("Process was successfully.");

            FactoServ.getInstance().extra(new FactoEntity().setCar("rio").setColor("black").setYear(1380)
                    .setPrice(23000000).setId(2));
        } catch (Exception e) {
            System.out.println("Process error:" + e.getMessage());
        }

        try {
            FactoServ.getInstance().chose(new FactoEntity());
            System.out.println("Upgrade was successfully.");

            FactoServ.getInstance().chose(new FactoEntity());
        } catch (Exception e) {
            System.out.println("Upgrade error:" + e.getMessage());
        }
    }
}
