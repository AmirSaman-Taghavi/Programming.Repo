package model.entity;

public class UserEnti {
    private String username;
    private String password;
    private int money;
    private int internet;
    private int g;

    public int getMoney() {
        return money;
    }

    public UserEnti setMoney(int money) {
        this.money = money;
        return this;
    }

    public int getG() {
        return g;
    }

    public UserEnti setG(int g) {
        this.g = g;
        return this;
    }

    public int getInternet() {
        return internet;
    }

    public UserEnti setInternet(int internet) {
        this.internet = internet;
        return this;
    }

    public String getUsername() {
        return username;
    }

    public UserEnti setUsername(String username) {
        this.username = username;
        return this;
    }

    public String getPassword() {
        return password;
    }

    public UserEnti setPassword(String password) {
        this.password = password;
        return this;
    }
}
