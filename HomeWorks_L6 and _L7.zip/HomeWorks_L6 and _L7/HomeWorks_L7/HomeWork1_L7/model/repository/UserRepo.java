package model.repository;
import model.entity.UserEnti;
import java.sql.*;

public class UserRepo implements AutoCloseable{
    private Connection connection;
    private PreparedStatement preparedStatement;
    public UserRepo() throws Exception{
        Class.forName("oracle.jdbc.driver.OracleDriver");
        connection = DriverManager.getConnection("jdbc:oracle:thin:@LAPTOP-UPV59LDR:1521:xe", "java"
        , "samrod82");
        connection.setAutoCommit(false);
    }
    public void insert(UserEnti userEnti) throws Exception {
        preparedStatement = connection.prepareStatement("insert into userb(uname, pword, inter, g, money) values " +
            "(?, ?, ?, ?, ?)");
        preparedStatement.setString(1, userEnti.getUsername());
        preparedStatement.setString(2, userEnti.getPassword());
        preparedStatement.setLong(3, userEnti.getInternet());
        preparedStatement.setLong(4, userEnti.getG());
        preparedStatement.setLong(5, userEnti.getMoney());
        preparedStatement.executeUpdate();
    }
    public void commit() throws Exception {
        connection.commit();
    }
    public void rollback() throws Exception {
        connection.rollback();
    }
    public void close() throws Exception {
        preparedStatement.close();
        connection.close();
    }
}
