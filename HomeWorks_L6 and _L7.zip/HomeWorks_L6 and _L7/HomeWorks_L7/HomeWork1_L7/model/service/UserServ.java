package model.service;
import model.entity.UserEnti;
import model.repository.UserRepo;

public class UserServ {
    public UserServ() {

    }

    private static UserServ userServ = new UserServ();
    public static UserServ getInstance() {
        return userServ;
    }
    public void save(UserEnti userEnti) throws Exception {
        try(UserRepo userRepo = new UserRepo()) {
            switch (userEnti.getInternet()) {
                case 1000:
                    userEnti.setInternet(userEnti.getMoney() - 1000);
                    userEnti.setG(userEnti.getG() + 2);
                    userRepo.insert(userEnti);
                    userRepo.commit();
                    break;
                case 2000:
                    userEnti.setInternet(userEnti.getInternet() - 2000);
                    userEnti.setG(userEnti.getG() + 4);
                    userRepo.insert(userEnti);
                    userRepo.commit();
                    break;
                case 5000:
                    userEnti.setInternet(userEnti.getInternet() - 5000);
                    userEnti.setG(userEnti.getG() + 10);
                    userRepo.insert(userEnti);
                    userRepo.commit();
                    break;
                case 10000:
                    userEnti.setInternet(userEnti.getInternet() - 1000);
                    userEnti.setG(userEnti.getG() + 25);
                    userRepo.insert(userEnti);
                    userRepo.commit();
                    break;
                default:
                    userEnti.setInternet(userEnti.getInternet());
                    userEnti.setG(userEnti.getG());
                    userRepo.insert(userEnti);
                    userRepo.commit();
                    break;
            }
        }
    }
}
