import controller.UserCont;

public class HomeWork {
    public static void main(String[] args) {
        UserCont userCont = new UserCont();
        userCont.control();
    }
}
