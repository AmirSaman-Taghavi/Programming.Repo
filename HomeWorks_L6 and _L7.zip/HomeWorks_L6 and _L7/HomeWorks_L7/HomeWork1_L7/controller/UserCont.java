package controller;
import model.entity.UserEnti;
import model.service.UserServ;

public class UserCont {
    public void control() {
        try {
            UserServ.getInstance().save(new UserEnti().setUsername("amirmahdi45").setPassword("farjadoop1")
                    .setInternet(2000).setG(0).setMoney(30000));
            System.out.println("Saved successfully.");
        } catch (Exception e) {
            System.out.println("Fail to save:" + e.getMessage());
        }
    }
}
