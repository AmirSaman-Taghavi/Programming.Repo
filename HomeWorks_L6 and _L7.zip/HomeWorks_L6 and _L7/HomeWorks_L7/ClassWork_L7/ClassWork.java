import controller.UserCont;

public class ClassWork {
    public static void main(String[] args) {
        UserCont userCont = new UserCont();
        userCont.check_Reg();
        userCont.check_LogIn();
    }
}
