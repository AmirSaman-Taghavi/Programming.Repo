package model.service;
import model.entity.UserEnt;
import model.repository.UserRepo;

public class UserServ {
    int n = 30;
    private static UserServ userServ = new UserServ();
    public static UserServ getInstance() {
        return userServ;
    }
    private UserServ() {

    }
    public void register(UserEnt userEnt) throws Exception {
        try (UserRepo userRepo = new UserRepo()) {
            userRepo.insert1(userEnt);
            userRepo.commit();
        }
    }

    public void logIn(UserEnt userEnt) throws Exception {
        try (UserRepo userRepo = new UserRepo()) {
            userRepo.insert2(userEnt);
            userRepo.commit();
        }
    }
}
