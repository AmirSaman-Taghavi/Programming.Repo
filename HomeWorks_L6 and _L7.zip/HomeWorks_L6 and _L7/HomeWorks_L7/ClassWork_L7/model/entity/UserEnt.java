package model.entity;

public class UserEnt {
    private String name;
    private String pass;
    private String username;
    private String email;
    private int id;

    public int getId() {
        return id;
    }

    public UserEnt setId(int id) {
        this.id = id;
        return this;
    }

    public String getName() {
        return name;
    }

    public UserEnt setName(String name) {
        this.name = name;
        return this;
    }

    public String getPass() {
        return pass;
    }

    public UserEnt setPass(String pass) {
        this.pass = pass;
        return this;
    }

    public String getUsername() {
        return username;
    }

    public UserEnt setUsername(String username) {
        this.username = username;
        return this;
    }

    public String getEmail() {
        return email;
    }

    public UserEnt setEmail(String email) {
        this.email = email;
        return this;
    }
}
