package repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Human {
    public void person() {
        Connection connection;
        PreparedStatement preparedStatement;
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            connection = DriverManager.getConnection("jdbc:oracle:thin:@LAPTOP-UPV59LDR:1521:xe"
                    , "upgrade", "samrod82");
            preparedStatement = connection.prepareStatement("insert into human(n,db,u,p,c)values" +
                    "(?,?,?,?,?");
            preparedStatement.setString(1,"Ali Sadeghi");
            preparedStatement.setString(2,"1382/02/25");
            preparedStatement.setString(3, "@ali61");
            preparedStatement.setString(4, "sadeghi1832");
            preparedStatement.setString(5, "Mashhad");

            connection.close();
            preparedStatement.close();
        } catch (ClassNotFoundException ce) {
            System.out.println("ClassNotFoundException");
        } catch (SQLException se) {
            System.out.println("SQLException");
        }
    }
}
