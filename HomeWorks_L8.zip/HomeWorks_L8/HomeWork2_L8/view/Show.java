package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class Show {
    public void showPage() {
        JFrame jFrame = new JFrame("User");
        GridLayout gridLayout = new GridLayout(12, 12);
        jFrame.setLayout(gridLayout);
        jFrame.setLocation(0, 0);
        jFrame.setSize(700, 600);

        JLabel lblUsername = new JLabel("Username = ");
        lblUsername.setLocation(0, 0);
        lblUsername.setSize(70, 70);
        jFrame.add(lblUsername);

        JTextField txtUsername = new JTextField(20);
        txtUsername.setLocation(0, 0);
        txtUsername.setSize(70, 70);
        jFrame.add(txtUsername);

        JLabel lblPass = new JLabel("Pass = ");
        lblPass.setLocation(0, 0);
        lblPass.setSize(70, 70);
        jFrame.add(lblPass);

        JTextField txtPass = new JTextField(20);
        txtPass.setLocation(0, 0);
        txtPass.setSize(70, 70);
        jFrame.add(txtPass);


        JButton btnClick = new JButton("Click");
        btnClick.setLocation(0,0);
        btnClick.setSize(70, 70);
        jFrame.add(btnClick);

        Controller controller = new Controller();
        btnClick.addActionListener(controller);

        JLabel lblName = new JLabel("Name = ");
        lblName.setLocation(0, 0);
        lblName.setSize(70, 70);

        JTextField txtName = new JTextField("Ali Sadeghi");
        txtName.setLocation(0, 0);
        txtName.setSize(200, 200);

        JLabel lblBirth = new JLabel("Date of birth = ");
        lblBirth.setLocation(0, 0);
        lblBirth.setSize(200, 200);


        JTextField txtBirth = new JTextField("1382/02/25");
        txtBirth.setLocation(0, 0);
        txtBirth.setSize(200, 200);

        JLabel lblUsernamed = new JLabel("Username = ");
        lblUsernamed.setLocation(0, 0);
        lblUsernamed.setSize(200, 200);

        JTextField txtUsernamed = new JTextField("@ali61");
        txtUsernamed.setLocation(0, 0);
        txtUsernamed.setSize(200, 2100);

        JLabel lblPassd = new JLabel("Pass = ");
        lblPassd.setLocation(0, 0);
        lblPassd.setSize(200, 200);

        JTextField txtPassd = new JTextField("sadeghi8132");
        txtPassd.setLocation(0, 0);
        txtPassd.setSize(200, 200);

        JLabel lblCity = new JLabel("City = ");
        lblCity.setLocation(0, 0);
        lblCity.setSize(200, 200);

        JTextField txtCity = new JTextField("Mashhad");
        txtCity.setLocation(0, 0);
        txtCity.setSize(200, 200);

        JPanel jPanel = new JPanel();
        jPanel.setLocation(200, 200);
        jPanel.setSize(600, 600);
        //jPanel.setLayout(gridLayout);
        jPanel.add(lblName);
        jPanel.add(txtName);
        jPanel.add(lblBirth);
        jPanel.add(txtBirth);
        jPanel.add(lblUsernamed);
        jPanel.add(txtUsernamed);
        jPanel.add(lblPassd);
        jPanel.add(txtPassd);
        jPanel.add(lblCity);
        jPanel.add(txtCity);
        jPanel.setVisible(false);
        jFrame.add(jPanel);


        btnClick.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.out.println("...");
                jPanel.setVisible(true);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                System.out.println("...");
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                System.out.println("...");
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                System.out.println("...");
            }

            @Override
            public void mouseExited(MouseEvent e) {
                System.out.println("...");
            }
        });

        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
