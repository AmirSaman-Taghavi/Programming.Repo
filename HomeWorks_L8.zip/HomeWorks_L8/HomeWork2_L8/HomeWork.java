import view.Controller;
import view.Show;

public class HomeWork {
    public static void main(String[] args) {
        Show show = new Show();
        show.showPage();

    }
}
