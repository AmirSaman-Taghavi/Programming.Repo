import repository.Employee;
import view.ViewEmployee;

public class HomeWork {
    public static void main(String[] args) {
        Employee employee = new Employee();
        employee.employee();

        ViewEmployee viewEmployee = new ViewEmployee();
        viewEmployee.viewE();
    }
}
