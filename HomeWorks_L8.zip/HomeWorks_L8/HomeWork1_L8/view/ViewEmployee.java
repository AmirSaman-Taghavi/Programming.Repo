package view;

import javax.swing.*;
import java.awt.*;

public class ViewEmployee {
    public void viewE() {
        JFrame jFrame = new JFrame("Employment form");
        GridLayout gridLayout = new GridLayout(10,10);
        jFrame.setLayout(gridLayout);
        jFrame.setLocation(0,0);
        jFrame.setSize(500, 500);

        JLabel lblName = new JLabel("Name = ");
        lblName.setLocation(0, 0);
        lblName.setSize(70, 70);
        lblName.setLayout(gridLayout);
        jFrame.add(lblName);

        JTextField txtName = new JTextField(20);
        txtName.setLocation(0, 0);
        txtName.setSize(70, 70);
        txtName.setFont(Font.getFont(Font.SERIF));
        txtName.setLayout(gridLayout);
        jFrame.add(txtName);

        JLabel lblNumber = new JLabel("Mobile number = ");
        lblNumber.setLocation(0, 0);
        lblNumber.setSize(70, 70);
        lblNumber.setLayout(gridLayout);
        lblNumber.setLayout(gridLayout);
        jFrame.add(lblNumber);

        JTextField txtNumber = new JTextField(20);
        txtNumber.setLocation(0, 0);
        txtNumber.setSize(70, 70);
        txtNumber.setFont(Font.getFont(Font.SERIF));
        txtNumber.setLayout(gridLayout);
        jFrame.add(txtNumber);

        JLabel lblHNumber = new JLabel("Home number = ");
        lblHNumber.setLocation(0, 0);
        lblHNumber.setSize(70, 70);
        lblHNumber.setLayout(gridLayout);
        jFrame.add(lblHNumber);

        JTextField txtHNumber = new JTextField(20);
        txtHNumber.setLocation(0, 0);
        txtHNumber.setSize(70, 70);
        txtHNumber.setFont(Font.getFont(Font.SERIF));
        txtHNumber.setLayout(gridLayout);
        jFrame.add(txtHNumber);

        JLabel lblAddress = new JLabel("Address = ");
        lblAddress.setLocation(0, 0);
        lblAddress.setSize(70, 70);
        lblAddress.setLayout(gridLayout);
        lblAddress.setLayout(gridLayout);
        jFrame.add(lblAddress);

        JTextField txtAddress = new JTextField(20);
        txtAddress.setLocation(0, 0);
        txtAddress.setSize(70, 70);
        txtAddress.setFont(Font.getFont(Font.SERIF));
        txtAddress.setLayout(gridLayout);
        jFrame.add(txtAddress);

        JLabel lblWYear = new JLabel("Work experience to the year = ");
        lblWYear.setLocation(0, 0);
        lblWYear.setSize(70, 70);
        lblWYear.setLayout(gridLayout);
        jFrame.add(lblWYear);

        JTextField txtWYear = new JTextField(20);
        txtWYear.setLocation(0, 0);
        txtWYear.setSize(70, 70);
        txtWYear.setFont(Font.getFont(Font.SERIF));
        txtWYear.setLayout(gridLayout);
        jFrame.add(txtWYear);

        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
