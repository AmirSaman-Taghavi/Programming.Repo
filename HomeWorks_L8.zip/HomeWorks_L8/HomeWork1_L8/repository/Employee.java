package repository;
import java.sql.*;

public class Employee{
    private Connection connection;
    public void employee(){
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            connection = DriverManager.getConnection("jdbc:oracle:thin:@LAPTOP-UPV59LDR:1521:xe", "CEO",
                    "samrod82");
            connection.close();
        } catch (ClassNotFoundException ce) {
            System.out.println("ClassNotFoundException = " + ce.getMessage());
        } catch (SQLException se) {
            System.out.println("SQLException = " + se.getMessage());
        } catch (Exception e) {
            System.out.println("Another types of Error = " + e.getMessage());
        }
    }
}
