package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Control implements ActionListener {
    @Override
    public void actionPerformed (ActionEvent e){
        switch (e.getActionCommand()) {
            case "Register":
                System.out.println("Registered successfully.");
                break;
            case "LogIn":
                System.out.println("LogIn successfully.");
                break;
            default:
                System.out.println("Failed");
        }
    }
}

