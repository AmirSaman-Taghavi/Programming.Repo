package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class UserView {
    public void view() {
        JFrame jFrame = new JFrame("User");
        GridLayout gridLayout = new GridLayout(13, 13);
        jFrame.setLayout(gridLayout);
        jFrame.setLocation(0, 0);
        jFrame.setSize(800, 800);

        JLabel lblName = new JLabel("Name = ");
        lblName.setLocation(0, 0);
        lblName.setSize(70, 70);
        jFrame.add(lblName);

        JTextField txtName = new JTextField(20);
        txtName.setLocation(0, 0);
        txtName.setSize(70, 70);
        txtName.setFont(Font.getFont(Font.SERIF));
        jFrame.add(txtName);

        JLabel lblPass = new JLabel("Pass = ");
        lblPass.setLocation(0, 0);
        lblPass.setSize(70, 70);
        jFrame.add(lblPass);

        JTextField txtPass = new JTextField(20);
        txtPass.setLocation(0, 0);
        txtPass.setSize(70, 70);
        txtPass.setFont(Font.getFont(Font.SERIF));
        jFrame.add(txtPass);

        JLabel lblUsername = new JLabel("Username = ");
        lblUsername.setLocation(0, 0);
        lblUsername.setSize(70, 70);
        jFrame.add(lblUsername);

        JTextField txtUsername = new JTextField(20);
        txtUsername.setLocation(0, 0);
        txtUsername.setSize(70, 70);
        txtUsername.setFont(Font.getFont(Font.SERIF));
        jFrame.add(txtUsername);

        JLabel lblEmail = new JLabel("Email = ");
        lblEmail.setLocation(0, 0);
        lblEmail.setSize(70, 70);
        jFrame.add(lblEmail);

        JTextField txtEmail = new JTextField(20);
        txtEmail.setLocation(0, 0);
        txtEmail.setSize(70, 70);
        txtEmail.setFont(Font.getFont(Font.SERIF));
        jFrame.add(txtEmail);

        JButton btnRegister = new JButton("Register");
        btnRegister.setLocation(0, 0);
        btnRegister.setSize(70, 70);
        btnRegister.setLayout(gridLayout);
        jFrame.add(btnRegister);

        Control control = new Control();
        btnRegister.addActionListener(control);

        JLabel lblPassr = new JLabel("Pass = ");
        lblPassr.setLocation(0, 0);
        lblPassr.setSize(70, 70);

        JTextField txtPassr = new JTextField(20);
        txtPassr.setLocation(0, 0);
        txtPassr.setSize(70, 70);
        txtPassr.setFont(Font.getFont(Font.SERIF));

        JLabel lblUsernamer = new JLabel("Username = ");
        lblUsernamer.setLocation(0, 0);
        lblUsernamer.setSize(70, 70);

        JTextField txtUsernamer = new JTextField(20);
        txtUsernamer.setLocation(0, 0);
        txtUsernamer.setSize(70, 70);
        txtUsernamer.setFont(Font.getFont(Font.SERIF));

        JPanel jPanel = new JPanel();
        jPanel.setLocation(0, 200);
        jPanel.setSize(400, 400);
        jPanel.add(lblPassr);
        jPanel.add(txtPassr);
        jPanel.add(lblUsernamer);
        jPanel.add(txtUsernamer);
        jPanel.setVisible(false);
        jFrame.add(jPanel);

        btnRegister.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jPanel.setVisible(true);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                System.out.println("...");
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                System.out.println("...");
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                System.out.println("...");
            }

            @Override
            public void mouseExited(MouseEvent e) {
                System.out.println("...");
            }
        });

        JButton btnLogIn = new JButton("LogIn");
        btnLogIn.setLocation(0, 0);
        btnLogIn.setSize(70, 70);
        btnLogIn.setLayout(gridLayout);
        jFrame.add(btnLogIn);

        btnLogIn.addActionListener(control);

        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
