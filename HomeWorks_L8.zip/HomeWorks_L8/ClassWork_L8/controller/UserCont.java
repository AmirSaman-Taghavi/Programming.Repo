package controller;
import model.entity.UserEnt;
import model.service.UserServ;

public class UserCont {
    public void check_Reg() {
        try {
            UserServ.getInstance().register(new UserEnt().setName("farhad").setPass("farhad813").setUsername("@farhadyazdani")
                    .setEmail("farhadyasdani@gmail.com").setId(1));
            System.out.println("register successfully.");
        } catch (Exception e) {
            System.out.println("error:" + e.getMessage());
        }
    }
    public void check_LogIn() {
        try {
            UserServ.getInstance().logIn(new UserEnt().setUsername("@farhadyazdani").setPass("farhad813"));
            System.out.println("LogIn successfully.");
        } catch (Exception e) {
            System.out.println("error:" + e.getMessage());
        }
    }
}