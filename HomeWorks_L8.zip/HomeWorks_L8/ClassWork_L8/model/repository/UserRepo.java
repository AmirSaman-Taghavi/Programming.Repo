package model.repository;
import model.entity.UserEnt;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;
import java.util.Calendar;
import java.util.Map;

public class UserRepo implements AutoCloseable{
    private Connection connection;
    private PreparedStatement preparedStatement;
    public UserRepo() throws Exception {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        connection = DriverManager.getConnection("jdbc:oracle:thin:@LAPTOP-UPV59LDR:1521:xe" ,"maniar"
            , "samrod82");
        connection.setAutoCommit(false);
    }
    public void insert1(UserEnt userEnt) throws Exception {
        preparedStatement = connection.prepareStatement("Insert into users(name, pass, username, email, id)values" +
            "(?, ?, ?, ?, ?)");
        preparedStatement.setString(1, userEnt.getName());
        preparedStatement.setString(2, userEnt.getPass());
        preparedStatement.setString(3, userEnt.getUsername());
        preparedStatement.setString(4, userEnt.getEmail());
        preparedStatement.setLong(5, userEnt.getId());
        preparedStatement.executeUpdate();
    }
    public void insert2(UserEnt userEnt) throws Exception {
        preparedStatement = connection.prepareStatement("insert into usera(username, pass)values(?, ?)");
        preparedStatement.setString(1, userEnt.getUsername());
        preparedStatement.setString(2, userEnt.getPass());
        preparedStatement.executeUpdate();
    }
    public void commit() throws Exception{
        connection.commit ();
    }
    public void rollback() throws Exception{
        connection.rollback ();
    }
    public void close() throws Exception {
        preparedStatement.close();
        connection.close();
    }
}

