import controller.UserCont;
import view.UserView;

public class ClassWork {
    public static void main(String[] args) {
        UserCont userCont = new UserCont();
        userCont.check_Reg();
        userCont.check_LogIn();

        UserView userView = new UserView();
        userView.view();
    }
}
