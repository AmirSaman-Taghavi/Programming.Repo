import model.repository.PersonData;
import model.view.PersonView;
import showfile.ReadFile;

public class HomeWork {
    public static void main(String[] args) {
        PersonView personView = new PersonView();

        Thread thread1 = new Thread(personView);

        PersonData personData = new PersonData();

        Thread thread2 = new Thread(personData);

        ReadFile readFile = new ReadFile();

        Thread thread3 = new Thread(readFile);

        thread1.start();
        thread2.start();
        thread3.start();
    }
}
