package model.view;

import javax.swing.*;
import java.awt.*;

public class PersonView implements Runnable{
    public void information() {
        JFrame jFrame = new JFrame("Person's information");
        GridLayout gridLayout = new GridLayout(5,5);
        jFrame.setLayout(gridLayout);
        jFrame.setLocation(0,0);
        jFrame.setSize(400,400);

        JLabel lblname = new JLabel("Name and Surname: ");
        lblname.setLayout(gridLayout);
        lblname.setLocation(0,0);
        lblname.setSize(100, 100);
        jFrame.add(lblname);

        JTextField txtname = new JTextField();
        txtname.setLayout(gridLayout);
        txtname.setLocation(0, 0);
        txtname.setSize(100, 100);
        jFrame.add(txtname);

        JLabel lblusername = new JLabel("Username: ");
        lblname.setLayout(gridLayout);
        lblname.setLocation(0,0);
        lblname.setSize(100, 100);
        jFrame.add(lblusername);

        JTextField txtusername = new JTextField();
        txtname.setLayout(gridLayout);
        txtname.setLocation(0, 0);
        txtname.setSize(100, 100);
        jFrame.add(txtusername);

        JLabel lblpassword = new JLabel("Password: ");
        lblname.setLayout(gridLayout);
        lblname.setLocation(0,0);
        lblname.setSize(100, 100);
        jFrame.add(lblpassword);

        JTextField txtpassword = new JTextField();
        txtname.setLayout(gridLayout);
        txtname.setLocation(0, 0);
        txtname.setSize(100, 100);
        jFrame.add(txtpassword);

        JLabel lblage = new JLabel("Age: ");
        lblname.setLayout(gridLayout);
        lblname.setLocation(0,0);
        lblname.setSize(100, 100);
        jFrame.add(lblage);

        JTextField txtage = new JTextField();
        txtname.setLayout(gridLayout);
        txtname.setLocation(0, 0);
        txtname.setSize(100, 100);
        jFrame.add(txtage);

        jFrame.setVisible(true);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    @Override
    public void run() {
        information();
    }
}
