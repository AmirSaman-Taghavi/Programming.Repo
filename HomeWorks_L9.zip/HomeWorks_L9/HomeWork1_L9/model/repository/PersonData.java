package model.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PersonData implements Runnable{
    public void inputData() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe"
                , "idata", "samrod82");
            PreparedStatement preparedStatement = connection.prepareStatement("insert into pdata (name, username" +
                    ", password, age) values (?, ?, ?, ?)");
            preparedStatement.setString(1,"Sasan Ahmadi");
            preparedStatement.setString(2, "SAahM1");
            preparedStatement.setString(3, "MosherLow019");
            preparedStatement.setLong(4, 40);
            preparedStatement.close();
            connection.close();
        } catch (ClassNotFoundException ce) {
            ce.getStackTrace();
        } catch (SQLException se) {
            se.getStackTrace();
        }
    }

    @Override
    public void run() {
        inputData();
    }
}
