package showfile;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ReadFile implements Runnable{
    public void readFile() {
        try {
            File file = new File("C:\\Users\\amiir\\homework1_L9.txt");
            FileReader fileReader = new FileReader(file);
            int ascii = fileReader.read();
            String content = "";

            while(ascii != -1) {
                content += (char)ascii;
                ascii = fileReader.read();
            }
            System.out.println(content);
            fileReader.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    @Override
    public void run() {
        readFile();
    }
}
