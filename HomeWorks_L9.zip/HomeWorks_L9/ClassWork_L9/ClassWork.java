public class ClassWork {
    public static void main(String[] args) {
        CreateFile createFile = new CreateFile();

        Thread thread1 = new Thread(createFile);
        Thread thread2 = new Thread(createFile);

        thread1.start();
        thread2.start();
    }
}
