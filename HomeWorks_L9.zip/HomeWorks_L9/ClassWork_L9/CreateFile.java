import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;

public class CreateFile implements Runnable{
    public void readFile() {
        File file1 = new File("C:\\Users\\amiir\\OneDrive\\Documents\\Java1.txt");

        try {
            FileReader fileReader = new FileReader(file1);
            int ascii = fileReader.read();
            String content = "";

            while (ascii != -1) {
                content += (char)ascii;
                ascii = fileReader.read();
            }
            System.out.println(content);
            System.out.println("\n\n");
            fileReader.close();
        } catch(IOException ioe) {
            ioe.printStackTrace();
        }
    }

    public void writeFile() {
        File file1 = new File("C:\\Users\\amiir\\OneDrive\\Documents\\Java1.txt");
        File file2 = new File("C:\\Users\\amiir\\OneDrive\\Documents\\Java2.txt");

        try {
            FileWriter fileWriter = new FileWriter(file2);
            fileWriter.write(String.valueOf(file1));
            fileWriter.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    @Override
    public void run() {
        readFile();
        writeFile();
    }
}
