public class Person {
    private String name = null;
    private String family = null;
    private String age = null;
    private String pass = null;
    private String username = null;
    private String job = null;

    public String getName() {return this.name;}
    public String getFamily() {return this.family;}
    public String getAge() {return this.age;}
    public String getPass() {return this.pass;}
    public String getUsername() {return this.username;}
    public String getJob() {return this.job;}

    public void setPerson (String name, String family, String age, String pass, String username, String job) {
        this.name = name;
        this.family = family;
        this.age = age;
        this.pass = pass;
        this.username = username;
        this.job = job;
    }
}
