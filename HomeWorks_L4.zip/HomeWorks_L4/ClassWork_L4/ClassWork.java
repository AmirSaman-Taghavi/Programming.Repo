import java.util.Scanner;

public class ClassWork {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.print("Enter your name: ");
        String str1 = in.next();

        System.out.print("Enter your family: ");
        String str2 = in.next();

        System.out.print("Enter your age: ");
        String str3 = in.next();

        System.out.print("Enter your pass: ");
        String str4 = in.next();

        System.out.print("Enter your username: ");
        String str5 = in.next();

        System.out.print("Enter your job: ");
        String str6 = in.next();

        Person p = new Person();
        p.setPerson(str1, str2, str3, str4, str5, str6);

        System.out.print("\n\n");

        System.out.format("Your name = %s\n", p.getName());
        System.out.format("Your family = %s\n", p.getFamily());
        System.out.format("Your age = %s\n", p.getAge());
        System.out.format("Your pass = %s\n", p.getPass());
        System.out.format("Your username = %s\n", p.getUsername());
        System.out.format("Your job = %s\n", p.getJob());
    }
}

