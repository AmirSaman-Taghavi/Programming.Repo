public class Student {
    private String number = null;
    private String name = null;
    private String totalAverage = null;

    public String getNumber() {return this.number;}
    public void setNumber(String number) {this.number = number;}

    public String getName() {return this.name;}
    public void setName(String name) {this.name = name;}

    public String getTotalAverage() {return this.totalAverage;}
    public void setTotalAverage(String totalAverage) {this.totalAverage = totalAverage;}
}
