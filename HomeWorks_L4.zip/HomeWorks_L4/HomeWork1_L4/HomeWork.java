import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class HomeWork {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Student stu = new Student();

        System.out.print("Enter your student number: ");
        String number = in.next();
        stu.setNumber(number);

        System.out.print("Enter your name: ");
        String name = in.next();
        stu.setName(name);

        System.out.print("Enter your total average: ");
        String totalAverage = in.next();
        stu.setTotalAverage(totalAverage);

        System.out.print("\n\n");

        Map map = new LinkedHashMap();
        map.put(number, stu.getNumber());
        map.put(name, stu.getName());
        map.put(totalAverage, stu.getTotalAverage());

        Set set = map.keySet();
        for (Object ob : set) {
            System.out.println(ob);
        }


    }
}
