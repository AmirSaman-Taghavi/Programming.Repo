import com.sun.org.apache.xpath.internal.operations.String;

public class Student <NAME, NUMBER, FATHERSNAME> extends String {
    private NAME name = null;
    private NUMBER number = null;
    private FATHERSNAME fathersname = null;
    private float grade1 = 0;
    private float grade2 = 0;
    private float grade3 = 0;
    private float grade4 = 0;
    private float grade5 = 0;
    
    public NAME getName() {
        return this.name;
    }

    public void setName(NAME name) {
        this.name = name;
    }

    public NUMBER getNumber() {
        return this.number;
    }

    public void setNumber(NUMBER number) {
        this.number = number;
    }

    public FATHERSNAME getFathersname() {
        return this.fathersname;
    }

    public void setFathersname(FATHERSNAME fathersname) {
        this.fathersname = fathersname;
    }

    public float getGrade1() {
        return grade1;
    }

    public void setGrade1(float grade1) {
        this.grade1 = grade1;
    }

    public float getGrade2() {
        return grade2;
    }

    public void setGrade2(float grade2) {
        this.grade2 = grade2;
    }

    public float getGrade3() {
        return grade3;
    }

    public void setGrade3(float grade3) {
        this.grade3 = grade3;
    }

    public float getGrade4() {
        return grade4;
    }

    public void setGrade4(float grade4) {
        this.grade4 = grade4;
    }

    public float getGrade5() {
        return grade5;
    }

    public void setGrade5(float grade5) {
        this.grade5 = grade5;
    }
}
