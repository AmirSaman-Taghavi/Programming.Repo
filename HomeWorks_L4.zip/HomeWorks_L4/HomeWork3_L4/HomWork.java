import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class HomWork {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Student stu = new Student();
        List <Float> list = new ArrayList <> ();

        System.out.print("Enter your name: ");
        String str1 = in.next();
        stu.setName(str1);

        System.out.print("Enter your student number: ");
        String str2 = in.next();
        stu.setNumber(str2);

        System.out.print("Enter your father's name: ");
        String str3 = in.next();
        stu.setFathersname(str3);

        System.out.print("Enter your first score: ");
        float f1 = in.nextFloat();
        list.add(f1);

        System.out.print("Enter your second score: ");
        float f2 = in.nextFloat();
        list.add(f2);

        System.out.print("Enter your third score: ");
        float f3 = in.nextFloat();
        list.add(f3);

        System.out.print("Enter your fourth score: ");
        float f4 = in.nextFloat();
        list.add(f4);

        System.out.print("Enter your fifth score: ");
        float f5 = in.nextFloat();
        list.add(f5);

        System.out.print("\n---------------------------------------\n");

        System.out.format("Your name: %s\n", stu.getName());
        System.out.format("Your student number: %s\n", stu.getNumber());
        System.out.format("Your father's name: %s\n", stu.getFathersname());

        System.out.println();

        for (float f : list) {
            System.out.println(f);
        }
    }
}
