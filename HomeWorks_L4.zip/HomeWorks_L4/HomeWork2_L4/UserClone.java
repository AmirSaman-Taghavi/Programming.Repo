public class UserClone implements Cloneable{
    public String username;
    public String password;

    @Override
    protected Object clone() throws CloneNotSupportedException{
        return super.clone();
    }
}
