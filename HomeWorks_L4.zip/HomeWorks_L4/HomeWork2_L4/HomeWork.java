import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class HomeWork {
    public static void main(String[] args) {
        User user = new User();
        List <String> list = new ArrayList<>();

        Scanner in = new Scanner(System.in);

        System.out.print("Enter your username: ");
        String str1 = in.next();
        user.setUsername(str1);
        list.add(user.getUsername());

        System.out.print("Enter your password: ");
        String str2 = in.next();
        user.setPassword(str2);
        list.add(user.getPassword());

        System.out.print("\n$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$\n");

        System.out.format("Your username: %s\n", user.getUsername());
        System.out.format("Your password: %s\n", user.getPassword());

        UserClone userClone = new UserClone();
        userClone.username = str1;
        userClone.password = str2;

        UserClone userClone1 = null;
        try {
            userClone1 = (UserClone) userClone.clone();
        } catch (CloneNotSupportedException ce) {
            System.out.println(ce.getClass());
            System.out.println(ce.getMessage());
            System.out.println("Clone not supported!");
        } catch (NullPointerException ne) {
            System.out.println(ne.getClass());
            System.out.println(ne.getMessage());
            System.out.println("This Array is null!");
        }

        if (!userClone.equals(userClone1)) {
            System.out.println(userClone);
            System.out.println(userClone.username);
            System.out.println(userClone.password);

            System.out.print("\n_________________________________\n");

            System.out.println(userClone1);
            System.out.println(userClone1.username);
            System.out.println(userClone1.password);
        }

        System.out.println("**************************************\n");

        UserClone userClone2 = null;
        try {
            userClone2 = (UserClone) userClone.clone();
        } catch (CloneNotSupportedException ce) {
            System.out.println(ce.getClass());
            System.out.println(ce.getMessage());
            System.out.println("Clone not supported!");
        } catch (NullPointerException ne) {
            System.out.println(ne.getClass());
            System.out.println(ne.getMessage());
            System.out.println("This Array is null!");
        }

        if (!userClone.equals(userClone2)) {
            System.out.println(userClone);
            System.out.println(userClone.username);
            System.out.println(userClone.password);

            System.out.print("\n_________________________________\n");

            System.out.println(userClone2);
            System.out.println(userClone2.username);
            System.out.println(userClone2.password);
        }

        System.out.println("**************************************\n");

        UserClone userClone3 = null;
        try {
            userClone3 = (UserClone) userClone.clone();
        } catch (CloneNotSupportedException ce) {
            System.out.println(ce.getClass());
            System.out.println(ce.getMessage());
            System.out.println("Clone not supported!");
        } catch (NullPointerException ne) {
            System.out.println(ne.getClass());
            System.out.println(ne.getMessage());
            System.out.println("This Array is null!");
        }

        if (!userClone.equals(userClone3)) {
            System.out.println(userClone);
            System.out.println(userClone.password);
            System.out.println(userClone.username);

            System.out.print("_________________________________\n");

            System.out.println(userClone3);
            System.out.println(userClone3.username);
            System.out.println(userClone3.password);
        }
    }
}
