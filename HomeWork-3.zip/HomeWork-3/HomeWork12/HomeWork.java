import java.util.*;

public class HomeWork {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter an Integer: ");
        int x = input.nextInt();

        NumberType np = new NumberType();
        np.isEven(x);
        np.isOdd(x);
        np.isPositive(x);
        np.isNegative(x);
        np.isZero(x);
    }
}
