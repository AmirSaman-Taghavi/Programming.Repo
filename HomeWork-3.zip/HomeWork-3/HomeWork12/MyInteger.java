public interface MyInteger {
    void isEven(int a);
    void isOdd(int a);
    void isPositive(int a);
    void isNegative(int a);
    void isZero(int a);
}
