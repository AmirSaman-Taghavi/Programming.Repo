public class NumberType implements MyInteger{
    @Override
    public void isEven(int b) {
        if (b % 2 == 0) {
            System.out.format("%d is an Even number.\n", b);
        }
    }

    @Override
    public void isOdd(int b) {
        if (b % 2 == 1) {
            System.out.format("%d is an Odd number.\n", b);
        }
    }

    @Override
    public void isPositive(int b) {
        if (b > 0) {
            System.out.format("%d is a Positive number.\n", b);
        }
    }

    @Override
    public void isNegative(int b) {
        if (b < 0) {
            System.out.format("%d is a Negative number.\n", b);
        }
    }

    @Override
    public void isZero(int b) {
        if (b == 0) {
            System.out.format("%d\n", b);
        }
    }
}
