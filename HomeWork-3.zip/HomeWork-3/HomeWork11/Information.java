public abstract class Information {
    public abstract void computer2();
    public abstract void physics2();
    public abstract void mathematics2();
    public abstract void farsiLanguage();

}
