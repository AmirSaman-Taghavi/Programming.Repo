public class HomeWork {
    public static void main(String[] args) {
        GiveInformation gi = new GiveInformation();
        gi.computer2();
        System.out.println("###################################");
        gi.physics2();
        System.out.println("###################################");
        gi.mathematics2();
        System.out.println("###################################");
        gi.farsiLanguage();
        System.out.println("###################################");
    }
}
