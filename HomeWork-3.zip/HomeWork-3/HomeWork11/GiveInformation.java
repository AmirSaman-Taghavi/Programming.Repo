public class GiveInformation extends Information{
    private static int n = 3;
    @Override
    public void computer2() {
        String str1 = "Computer2";
        System.out.format("The name of class = %s\n", str1);

        String str2 = "Computer1";
        System.out.format("Prerequisites = %s\n", str2);

        System.out.format("Number of units = %d\n", n);

        String str3 = "Nothing";
        System.out.format("Courses required = %s\n", str3);
    }

    @Override
    public void physics2() {
        String str1 = "Physics2";
        System.out.format("The name of class = %s\n", str1);

        String str2 = "Physics1";
        System.out.format("Prerequisites = %s\n", str2);

        System.out.format("Number of units = %d\n", n);

        String str3 = "Nothing";
        System.out.format("Courses required = %s\n", str3);
    }

    @Override
    public void mathematics2() {
        String str1 = "Mathematics2";
        System.out.format("The name of class = %s\n", str1);

        String str2 = "Mathematics1";
        System.out.format("Prerequisites = %s\n", str2);

        System.out.format("Number of units = %d\n", n);

        String str3 = "Nothing";
        System.out.format("Courses required = %s\n", str3);
    }

    @Override
    public void farsiLanguage() {
        String str1 = "Farsi language";
        System.out.format("The name of class = %s\n", str1);

        String str2 = "Nothing";
        System.out.format("Prerequisites = %s\n", str2);

        System.out.format("Number of units = %d\n", n);

        String str3 = "Nothing";
        System.out.format("Courses required = %s\n", str3);
    }
}
