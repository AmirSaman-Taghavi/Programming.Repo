public class Calculation implements Calculation1{
    @Override
    public void calculation(double a, double b) {
        double sum = a + b;
        System.out.format("Sum = %f", sum);
        System.out.println();

        double sub = a - b;
        System.out.format("Subtraction = %f", sub);
        System.out.println();

        double mul = a * b;
        System.out.format("Multiplication = %f", mul);
        System.out.println();

        double div = a / b;
        System.out.format("Division = %f", div);
        System.out.println();
    }
}

