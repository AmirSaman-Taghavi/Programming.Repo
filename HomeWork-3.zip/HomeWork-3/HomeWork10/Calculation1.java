public interface Calculation1 {
    void calculation(double a, double b);

}
