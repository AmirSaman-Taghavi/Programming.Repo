public abstract class Employee {
    public abstract void r_E();
}
