public class RoleT extends Teacher{
    @Override
    public void r_T() {
        System.out.println("Teacher");
    }
}
