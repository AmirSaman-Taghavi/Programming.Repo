public class HomeWork {
    public static void main(String[] args) {
        RoleS roleS = new RoleS();
        roleS.r_S();

        System.out.println("-------------------");

        RoleT roleT = new RoleT();
        roleT.r_T();

        System.out.println("-------------------");

        RoleE roleE = new RoleE();
        roleE.r_E();
    }
}
