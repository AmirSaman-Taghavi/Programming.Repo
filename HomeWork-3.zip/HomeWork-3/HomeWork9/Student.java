public abstract class Student{
    public abstract void r_S();
}
