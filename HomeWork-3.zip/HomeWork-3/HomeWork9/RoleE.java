public class RoleE extends Employee{
    @Override
    public void r_E() {
        System.out.println("Employee");
    }
}
