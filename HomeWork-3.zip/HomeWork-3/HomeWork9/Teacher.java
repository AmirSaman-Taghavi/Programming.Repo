public abstract class Teacher {
   public abstract void r_T();
}
