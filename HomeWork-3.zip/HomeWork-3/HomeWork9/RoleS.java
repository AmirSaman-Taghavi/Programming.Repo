public class RoleS extends Student{
    @Override
    public void r_S() {
        System.out.println("Student");
    }
}