import java.util.Scanner;

public class HomeWork {
    public static void main(String[] args){
        int n;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter number of array members: ");
        n = input.nextInt();

        int i = 0;
        double[] a;
        System.out.println("Enter members of array(a): "+(i+1));
        a = new double[n];
        for ( i = 0; i < n; i++)
            a[i] = input.nextInt();

        double Max = a[0];
        for ( i = 0; i < n; i++)
            if (a[i] > Max)
                Max = a[i];
        System.out.format("Maximum = %f", Max);

    }
}
