import java.util.*;

public class HomeWork {
    public static void main(String[] args) {
        System.out.print("Enter number of array members: ");
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();

        double[] a;
        a = new double[n];
        int i;
        for (i = 0; i < n; i++) {
            System.out.println("Enter member of array(a): " + (i + 1));
            a[i] = input.nextInt();
        }
        System.out.print("Enter a number: ");
        int num = input.nextInt();

        int count = 0;
        boolean tof = false;
        for (i = 0; i < n; i++)
            if (num == a[i]) {
                tof = true;
                count++;
            }
        System.out.format("%d have been found %d times.\n", num, count);
        System.out.println(tof);
    }
}
