import java.util.*;

public class HomeWork {
    public static void main(String[] args) {
        int ans = 1;
        while (ans != 0) {
            System.out.println("Enter an integer(n): ");
            Scanner input1 = new Scanner(System.in);
            int n = input1.nextInt();

            System.out.println("Enter another integer(m): ");
            Scanner input2 = new Scanner(System.in);
            int m = input2.nextInt();

            int sum = n + m;            //1
            int sub1 = n - m;           //2
            int sub2 = m - n;           //2
            int mul = n * m;            //3
            float div = (float) n / m;  //4

            int num ;
            System.out.println("1-Sum  2-Subtraction  3-Multiplication  4-Division");
            System.out.print("Enter your chosen option(1  2  3  4): ");
            Scanner input3 = new Scanner(System.in);
            num = input3.nextInt();

            switch (num) {
                case 1: System.out.format("%d + %d = %d\n", n, m, sum); break;
                case 2:
                    if (n > m) System.out.format("%d - %d = %d\n", n, m, sub1);
                    else System.out.format("%d - %d = %d\n", m, n, sub2);
                    break;
                case 3: System.out.format("%d * %d = %d\n", n, m, mul); break;
                case 4: System.out.format("%d / %d = %f\n", n, m, div); break;

                default: System.out.print("Your entered number not found!\n");
            }
            System.out.print("Do you want to continue ?(1/0) 1=Yes  0=No: ");
            Scanner input4 = new Scanner(System.in);
            ans = input4.nextInt();
        }
    }
}
